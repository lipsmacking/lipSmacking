'use strict';
 
var foo = angular.module('Home');
 
// .controller('HomeController',
//     ['$scope','$http',
//     function ($scope,$http) {

//     	$http.get('http://52.91.34.71:3000/auth').then(function(response){

//     		$scope.db=response;
//     	})

    	
      
//     }])



foo.controller('TableController',
    ['$scope','$http','$rootScope','$location','$timeout',
    function ($scope,$http, $rootScope,$location,$timeout) {

 // socket.on('init', function (data) {
 //    alert("DAS")
 //  });
$scope.goToAddTable = function(){

  $location.path('addTable');
}


    // socketio.on('content:changed', function(data) {
    //     $scope.data = data;
    // });
    // $scope.submitContent = function() {
    //     socket.emit('content:changed', $scope.data);
    // };


$scope.goToMenu = function(){
$location.path('menu');

}

$scope.getTables = function() {
	console.log("I am running")
    $http.get('http://52.91.34.71:3000/tables').then(function(r) {
      $scope.table=$rootScope.toRows(r.data, 3)
$scope.tablesAll=r.data;
   // socketio.on('post', function (msg) {
   //          $scope.tickets.push(msg);
   //      });
      // $timeout($scope.poller(), 1);
    });
    
  }
  

$scope.genID=function(row, index){

  // if (selRow[index].tableStatus!='Ready'){
  //   alert("Please select a green table")
  // }
$scope.showID = true;
// console.log(row);
// console.log(index);
var selRow = row;

$rootScope.selTableId = selRow[index].id;
console.log($rootScope.selTableId);


    $scope.GenId = '123456';
}


$scope.AddTable=function()
{
console.log()
var result = $.grep($scope.tablesAll, function(e){ return e.tableNumber == $scope.tNo; });

if(result.length>0){
  // alert("Table Number "+ $scope.tNo+"already exists");
  $scope.errMsg = "Table Number "+ $scope.tNo+" already exists";
}
else{
    var newTable = {'tableNumber':$scope.tNo,'isEnabled':'True','tableStatus':'Ready','capacity':$scope.tCap};
    var config = {
                headers : {
                    'Content-Type': 'application/json'
                }
            }
// $rootScope.$broadcast('table_added',"hello");

    $http.post('http://52.91.34.71:3000/tables',newTable, config)
    .success(function(response) {
        $scope.successMessage="Table addded successfully"
        $scope.getTables();
        console.log(response)
            })
            .error(function (response) {
            });



$scope.tNo = "";
$scope.tCap = "";
}
}


    	
   		
      
    }]);

/******************* TableController ends here *********************/

/******************* MainController starts here *********************/
foo.controller('MainController', function($rootScope,$scope) {

$rootScope.toRows = function(arr, total){
    var i = 0, rows = [];
    while(i < arr.length){
        i % total == 0 && rows.push([]);
        rows[rows.length-1].push(arr[i++])
    }
    return rows
};

    // $rootScope.employees = [
    //     {username:'customer',password:'customer',role:1},
    //     {username:'waiter',password:'waiter',role:2},
    //     {username:'chef',password:'chef',role:3}
    // ];
});

/******************* MainController ends here *********************/

/******************* MenuController starts here *********************/

foo.controller('MenuController', function($rootScope,$scope,$http,$location) {


$scope.alertWaiter = function(){
console.log($rootScope.selTableId)
// rootScope.menuIdArray.push(a);

  var alert = {
      "tableID": $rootScope.selTableId,
      "customerID": 111,
      "waiterID": 111,  
      "msg":'alert' 
    }
  // $rootScope.selectedItems.push{itemID:}

    var config = {
                headers : {
                    'Content-Type': 'application/json'
                }
            }
// $rootScope.$broadcast('table_added',"hello");

    $http.post('http://52.91.34.71:3000/tablesAssignment  ',alert, config)
    .success(function(response) {
        $scope.successMessage="ordered";

        // $scope.getTables();
        console.log(response)
            })
            .error(function (response) {
            });
}




$scope.init=function(){


}
    $scope.getMenu = function(){
      	$scope.showID = false;
            $http.get('http://52.91.34.71:3000/menu').then(function(response){
    //console.log(response.data)
$scope.menus=response.data;
console.log($scope.menus)
})
        }


$scope.selectItem = function(a,menuItem){

// rootScope.menuIdArray.push(a);

$scope.mI = menuItem;
$scope.mI.isEnabled = false;

	var orderItem = {
    "orderStatus": "ordered",
    "tableAssignmentId": $rootScope.selTableId,
    "menu_id": a,
    "quantity": 1
  }
	// $rootScope.selectedItems.push{itemID:}

    var config = {
                headers : {
                    'Content-Type': 'application/json'
                }
            }
// $rootScope.$broadcast('table_added',"hello");

    $http.post('http://52.91.34.71:3000/orders',orderItem, config)
    .success(function(response) {
        $scope.successMessage="ordered";

        // $scope.getTables();
        console.log(response)
            })
            .error(function (response) {
            });
}


$scope.goToConfirmOrder = function(){
	$location.path('confirm');
}



});
/******************* MenuController ends here *********************/


;




/******************* ConfirmOrderController starts here *********************/

foo.controller('ConfirmOrderController', function($rootScope,$scope,$http,$location) {


$scope.getOrders = function() {
	// console.log("I am running")
    $http.get('http://52.91.34.71:3000/orders').then(function(r) {
      $scope.orders=r.data;
$scope.id = $rootScope.selTableId;
console.log($scope.id)




   // socketio.on('post', function (msg) {
   //          $scope.tickets.push(msg);
   //      });
      // $timeout($scope.poller(), 1);
    });
    
  }




$scope.payNFeednack = function(){
	$location.path('pay');
}





});